'''
Created on Nov 22, 2009

@author: pawn
'''

import os,sys,subprocess

def convertAllImages():
    for dirTriplet in os.walk('./'):
        directory = dirTriplet[0]
        filenames = dirTriplet[2]
        for filename in filenames:
            filenamePreExt,filenameExt = os.path.splitext(filename)
            #if 'reyscale' not in filenamePreExt \
            #and ('pdf' in filenameExt or 'eps' in filenameExt):
            if filename=='BoardPos.pdf':
                fullFilename = os.path.join(directory,filename)
                fullFilenamePreExt = os.path.join(directory,filenamePreExt)
                execString = 'inkscape --export-text-to-path --without-gui --file='+fullFilename+' --export-eps='+fullFilenamePreExt+"_Greyscale.eps"
                print 'Calling:',execString
                #os.system("convert -colorspace Gray "+fullFilename+" "+fullFilenamePreExt+"_Greyscale.eps")
                os.system(execString)

if __name__ == '__main__':
    convertAllImages()
