from Defines import *
import matplotlib
matplotlib.use("PDF")
import matplotlib.pyplot as plt

FILES = [
'../../out/Results/GoNoScaling/winStats.out',
#'../../out/Results/GoScalingNoRanged/winStats.out',
'../../out/Results/GoScalingBasic/winStats.out',
]

def plotWinPercents():
    fitnessMeans = []
    fitnessStdDevs = []
    for file in FILES:
        infile = open(file,'rb')
        currentGeneration = 0
        fitnessMeans.append([])
        fitnessStdDevs.append([])
        
        fitnessMean = fitnessMeans[-1]
        fitnessStdDev = fitnessStdDevs[-1]
        
        while True:
            line =  infile.readline()
            if len(line)==0:
                break
            fitnessMean.append(float(line.split(' ')[1]))
            fitnessStdDev.append(float(line.split(' ')[2]))
            
            currentGeneration = currentGeneration + 1

    print fitnessMeans[0]
    print 'CREATING PLOT'
    #plt.plot(range(500,1000),fitnessMeans[0][0:500],'g-',range(0,1000),fitnessMeans[1],'r-')
    
    plt.errorbar(range(500,1000)[0:500:25],fitnessMeans[0][0:500:25],fitnessStdDevs[0][0:500:25])
    plt.errorbar(range(0,1000)[::25],fitnessMeans[1][::25],fitnessStdDevs[1][::25])
    
    plt.ylabel("some numbers")
    plt.show()
    plt.savefig('./test.pdf')

def main():
    plotWinPercents()
    
if __name__ == "__main__":
    print(os.getcwd())
    cProfile.runctx('main()',globals(), {}, 'profile.txt')
    stats = pstats.Stats('profile.txt')
    stats.sort_stats('time')
    stats.print_stats(.1)
    #main()
    sys.exit(0)

    