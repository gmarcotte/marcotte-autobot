from Defines import *

PATHS = [
'./Results/OriginalFogelTrial2/',
'./Results/CheckersHyperNEAT3/',
'./Results/CheckersNoGeomTrial3/',
'./Results/CheckersSubstrateGeom_Thread2356/',
]

def combineFitnesses(path):
    outfile = open(path+'ConcatFitness.out','wb')
    infiles = []
    fitnessMean = []
    fitnessStdDev = []
    fitnessError = []
    for index in xrange(1,21):
        infiles.append( open((path+'/Run%02d_best.xml_fitness.out'%index),'rb') )
    currentGeneration = 0
    while True:
        outfile.write(
                      ('%-04d'%(currentGeneration+1)) 
                      )
         
        for fileIndex in xrange(1,21):
            line =  infiles[fileIndex-1].readline()
            if len(line)==0:
                return
            fitness = int(line.partition(' ')[2])
        
            outfile.write('%-010d' % fitness)
            
        outfile.write('\n')
        currentGeneration = currentGeneration + 1

def main():
    for path in PATHS:
        combineFitnesses(path)
    
if __name__ == "__main__":
    print(os.getcwd())
    cProfile.runctx('main()',globals(), {}, 'profile.txt')
    stats = pstats.Stats('profile.txt')
    stats.sort_stats('time')
    stats.print_stats(.1)
    #main()
    sys.exit(0)

    