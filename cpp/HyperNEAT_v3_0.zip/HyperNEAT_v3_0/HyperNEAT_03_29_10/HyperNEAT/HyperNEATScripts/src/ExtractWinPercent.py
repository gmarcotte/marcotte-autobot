from Defines import *

'''
PATHS = [
         './Results/GoNoScaling7/ConsoleOutput/',
         './Results/GoNoScaling7/ConsoleOutputHilbert/',
         ]
OUTPUT_FILE = './Results/GoNoScaling7/winPercents.dat' 
'''
''
PATHS = [
         './Results/GoScaling5To7_T2575_Euler/ConsoleOutput/',
         ]
OUTPUT_FILE = './Results/GoScaling5To7_T2575_Euler/winPercents.dat' 
''

FILE_MASKS = [
              'runQsub.sh.o24840.%RUN%',
              'runQsub.sh.o14957.%RUN%',
              'runQsub.sh.o9828.%RUN%',
              ]

def main():
    outfile = open(OUTPUT_FILE,'wb')
    winPercents = [None]*10000
    for t in xrange(0,10000):
        winPercents[t] = []
        
    for path in PATHS:
        for fileMask in FILE_MASKS:
            for runIndex in xrange(0,100):
                newFile = path + '/' + fileMask.replace('%RUN%', ('%d' % runIndex))
                #print 'Checking for file',newFile
                if os.path.isfile( newFile ):
                    print 'Found file ',newFile,'. Processing...'
                    infile = open(newFile)
                    
                    currentGeneration = 0
                    currentBestWinPercent = -1
                    previousBestWinPercent = -1
                    while True:
                        line =  infile.readline()
                        if len(line)==0:
                            winPercents[currentGeneration].append(currentBestWinPercent)
                            break
                        if line.find('overall_average')>=0:
                            if currentBestWinPercent==-1:
                                if currentGeneration>0:
                                    currentBestWinPercent = previousBestWinPercent
                                else:
                                    raise Exception("OOPS")
                               
                            winPercents[currentGeneration].append(currentBestWinPercent)
                            currentGeneration += 1
                            previousBestWinPercent = currentBestWinPercent
                            currentBestWinPercent = 0
                        elif line.find('BEST WIN PERCENT')>=0:
                            currentBestWinPercent = max(currentBestWinPercent,int(line.partition("%")[0].partition('BEST WIN PERCENT: ')[2]))
                       
    currentGeneration=0
    while len(winPercents[currentGeneration])>0:
        print 'Samples for generation: ',len(winPercents[currentGeneration])
        average = 0.0
        for item in winPercents[currentGeneration]:
            average += item
        average /= len(winPercents[currentGeneration])
        standardDev = 0.0
        for item in winPercents[currentGeneration]:
            standardDev += (item-average) ** 2
        standardDev = sqrt(standardDev / len(winPercents[currentGeneration]) )
        
        outfile.write( str(average) + ' ' + str(standardDev) + '\n')
        currentGeneration += 1

                
    
if __name__ == "__main__":
    print(os.getcwd())
    cProfile.runctx('main()',globals(), {}, 'profile.txt')
    stats = pstats.Stats('profile.txt')
    stats.sort_stats('time')
    stats.print_stats(.1)
    #main()
    sys.exit(0)

    