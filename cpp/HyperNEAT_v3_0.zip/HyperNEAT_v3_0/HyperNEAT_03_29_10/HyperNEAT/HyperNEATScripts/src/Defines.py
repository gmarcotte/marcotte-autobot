import math
import copy
import sys
import getopt
import pickle
import collections
import types
import random
import ctypes
import os
import xml 
import time
import heapq
#import sets
#import profile
import cProfile
import pstats
import numpy
import inspect
import collections
import xml.parsers.expat
import gzip
import zlib

from math import *
from statlib import stats
