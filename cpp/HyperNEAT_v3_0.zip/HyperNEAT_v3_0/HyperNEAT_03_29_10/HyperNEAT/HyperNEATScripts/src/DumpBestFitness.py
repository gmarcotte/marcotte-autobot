from Defines import *

#PATH = './Results/GoNoScaling7/'
PATH = './Results/GoScaling5To7_T2575_Euler'

FILE_MASKS = [
              'testGoScaling5To7_T2575_Euler_Run%RUN%.xml.backup.xml.gz',
              'testGoScaling5To7_T2575_Euler_Run%RUN%_best.xml.gz'
              ]

# 3 handler functions
def start_element(name, attrs):
    global currentGeneration
    global gotIndividual
    global outfile
    #print 'Start element:', name, attrs
    if name=='GeneticGeneration':
        currentGeneration = int(attrs['GenNumber'])
        #print 'On generation',currentGeneration
        gotIndividual = False
            
    elif name=='Individual':
        if gotIndividual==False:
            gotIndividual = True
            outfile.write(str(currentGeneration+1) + ' ' + str(int(float(attrs['Fitness']))) + '\n')            

def main():
    global currentGeneration
    global gotIndividual
    global outfile
    
    for fileMask in FILE_MASKS:
        for runIndex in xrange(0,100):
            newFile = PATH + '/' + fileMask.replace('%RUN%', ('%d' % runIndex))
            #print 'Checking for file',newFile
            if os.path.isfile( newFile ):
                print 'Found file ',newFile,'. Processing...'
                currentGeneration = 0
                gotIndividual = False
                outfile = open(newFile.replace('.xml.gz','_fitness.out'),'wb')
                parser = xml.parsers.expat.ParserCreate()
                parser.StartElementHandler = start_element
                
                parser.ParseFile(gzip.GzipFile((newFile),'rb'))
    
if __name__ == "__main__":
    print(os.getcwd())
    cProfile.runctx('main()',globals(), {}, 'profile.txt')
    stats = pstats.Stats('profile.txt')
    stats.sort_stats('time')
    stats.print_stats(.1)
    #main()
    sys.exit(0)

    