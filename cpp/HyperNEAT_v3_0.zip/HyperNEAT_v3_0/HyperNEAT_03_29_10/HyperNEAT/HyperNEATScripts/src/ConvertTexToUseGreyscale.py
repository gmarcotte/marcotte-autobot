'''
Created on Nov 22, 2009

@author: pawn
'''

import os,sys,re

def convertLyxToUseGreyscale(filename):
    data = open(filename).read()
    #newdata = data
    #print re.search('includegraphics',data)
    #newdata = re.sub('includegraphics\[([^\]]+?)\]\{([^\]]+?)\}','includegraphics[\g<1>]{\g<2>_Greyscale.eps}',data)
    
    newdata = re.sub('filename (\S+)\.eps','filename \g<1>_Greyscale.eps',data)
    newdata = re.sub('filename (\S+)\.pdf','filename \g<1>_Greyscale.eps',newdata)
    
    filenamePreExt,filenameExt = os.path.splitext(filename)
    print 'Saving to ',(filenamePreExt+'_Greyscale'+filenameExt)
    open(filenamePreExt+'_Greyscale'+filenameExt,'wb').write(newdata)

if __name__ == '__main__':
    convertLyxToUseGreyscale(sys.argv[1])
    pass