from Defines import *

PATHS = [
'./Results/GoNoScaling7/',
"./Results/GoScaling5To7_T2575_Euler/",
]

FILE_MASKS = [
              ['Fitness/testGoNoScaling7_T2575_Hilbert_Run%RUN%_best_fitness.out','Fitness/testGoNoScaling7_T2575_Neat_Run%RUN%_best_fitness.out'],
              ['Fitness/testGoScaling5To7_T2575_Euler_Run%RUN%.xml.backup_fitness.out',
               'testGoScaling5To7_T2575_Euler_Run%RUN%_best_fitness.out'
               ],
              ]

def combineFitnesses(path,fileMasks):
    outfile = open(path+'AverageFitness.out','wb')
    infiles = []
    fitnessMean = []
    fitnessStdDev = []
    fitnessError = []
    for fileMask in fileMasks:
        runIndex=1
        for runIndex in xrange(0,100):
            newFile = path + fileMask.replace('%RUN%', ('%d' % runIndex))
            if os.path.isfile( newFile ):
                print 'Found file',newFile
                infiles.append( open(newFile,'rb') )
    currentGeneration = 0
    while True:
        fitnessMean.append(0)
        fitnessStdDev.append(0)
        fitnessError.append(0)
        curFitnesses = []
        filesWithData=0
        for file in infiles:
            line =  file.readline()
            if len(line)==0:
                continue
            filesWithData += 1
            fitness = int(line.partition(' ')[2])
            curFitnesses.append(fitness)
            fitnessMean[currentGeneration] = fitnessMean[currentGeneration] + fitness
        
        if filesWithData==0:
            return
        
        fitnessMean[currentGeneration] = fitnessMean[currentGeneration] / filesWithData
        for fitness in curFitnesses:
            fitnessStdDev[currentGeneration] = fitnessStdDev[currentGeneration] + (fitness-fitnessMean[currentGeneration]) ** 2
        fitnessStdDev[currentGeneration] = sqrt(fitnessStdDev[currentGeneration] / filesWithData)
        fitnessError[currentGeneration] = fitnessStdDev[currentGeneration]/sqrt(filesWithData)
        
        outfile.write(
                      ('%-04d'%(currentGeneration+1)) + 
                      ('%15.3f'%fitnessMean[currentGeneration]) + 
                      ('%15.3f'%fitnessStdDev[currentGeneration]) + 
                      ('%15.3f'%fitnessError[currentGeneration]) + 
                      '\n'
                      )
        currentGeneration = currentGeneration + 1

def main():
    for pathIndex in xrange(0,len(PATHS)):
        combineFitnesses(PATHS[pathIndex],FILE_MASKS[pathIndex])
    
if __name__ == "__main__":
    print(os.getcwd())
    cProfile.runctx('main()',globals(), {}, 'profile.txt')
    stats = pstats.Stats('profile.txt')
    stats.sort_stats('time')
    stats.print_stats(.1)
    #main()
    sys.exit(0)

    