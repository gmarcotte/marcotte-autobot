from Defines import *

'''
PATH = './Results/GoNoScaling/'
FILE_MASKS = [
              'testGoNoScaling_T2610_Euler_Run%RUN%_best.xml.gz'
              ]
'''
'''
PATH = './Results/GoScalingBasic/'
FILE_MASKS = [
              'GoScalingBasic_T2610_Hilbert_Run%RUN%_best.xml.gz'
              ]
'''
'''
PATH = './Results/GoScalingDeltaOnly/'
FILE_MASKS = [
              'GoScalingDeltaOnly_T2610_Hilbert_Run%RUN%_best.xml.gz'
              ]
'''
''
PATH = './Results/GoScalingDeltaOnlyNoRanged/'
FILE_MASKS = [
              'GoScalingDeltaOnlyNoRanged_T2610_Neat_Run%RUN%_best.xml.gz'
              ]
''
'''
PATH = './Results/GoScalingNoRanged/'
FILE_MASKS = [
              'GoScalingNoRanged_T2610_Neat_Run%RUN%_best.xml.gz'
              ]
'''

# 3 handler functions
def start_element(name, attrs):
    global currentGeneration
    global gotIndividual
    global winsList
    #print 'Start element:', name, attrs
    if name=='GeneticGeneration':
        currentGeneration = int(attrs['GenNumber'])
        #print 'On generation',currentGeneration
        gotIndividual = False
            
    elif name=='Individual':
        if gotIndividual==False:
            gotIndividual = True
            userData = attrs['UserData']
            wins,losses = userData.split(' ')
            wins = int(wins)
            losses = int(losses)
            while len(winsList)<=currentGeneration:
                winsList.append([])
            winsList[currentGeneration].append(wins)

def main():
    global currentGeneration
    global gotIndividual
    global winsList
    
    winsList = []
    
    for fileMask in FILE_MASKS:
        for runIndex in xrange(0,100):
            newFile = PATH + '/' + fileMask.replace('%RUN%', ('%d' % runIndex))
            #print 'Checking for file',newFile
            if os.path.isfile( newFile ):
                print 'Found file ',newFile,'. Processing...'
                currentGeneration = 0
                gotIndividual = False
                parser = xml.parsers.expat.ParserCreate()
                parser.StartElementHandler = start_element
                
                parser.ParseFile(gzip.GzipFile((newFile),'rb'))
    
    outfile = open(PATH+'/winStats.out','wb')
    for generation in xrange(0,len(winsList)):
        outfile.write(str(generation+1)+' '+str(stats.mean(winsList[generation]))+' '+str(stats.stdev(winsList[generation]))+'\n')
    
if __name__ == "__main__":
    print(os.getcwd())
    cProfile.runctx('main()',globals(), {}, 'profile.txt')
    stats = pstats.Stats('profile.txt')
    stats.sort_stats('time')
    stats.print_stats(.1)
    #main()
    sys.exit(0)

    