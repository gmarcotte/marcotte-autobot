find ./ | grep "\.c[p]*$" | xargs -I repme /cygdrive/c/Programming/test/DebugCodeParser.exe repme repme EPLEX_INTERNAL
find ./ | grep "\.h[p]*$" | xargs -I repme /cygdrive/c/Programming/test/DebugCodeParser.exe repme repme EPLEX_INTERNAL
pushd NEAT
/cygdrive/c/Programming/test/CmakeFileCleaner.exe
popd
pushd Hypercube_NEAT
/cygdrive/c/Programming/test/CmakeFileCleaner.exe
popd
pushd out/data
rm *~
rm *CheckersExperimentPruning*
rm *CheckersScalingExperiment*
rm *CoCheckersExperiment*
rm *Othello*
rm *Chess*
rm *parameters*
rm *ImageCompression*
rm *RobotArm*
rm *SimpleImageExperiment*
rm *Spatial*
rm *XorCoExperiment*
rm *xml.gz
popd
rm -Rf CPPN_NEAT
rm -Rf NEAT_GetFood
rm -Rf NEAT_Riot
rm -Rf NEAT_Visualizer
rm -Rf Xor
rm -Rf GPUANN

