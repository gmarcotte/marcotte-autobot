from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
from math import *

from Vector3 import *
from Vector2 import *

import sys,os

import GlobalData

if os.getcwd() not in sys.path:
    print 'Looking for PyHyperNEAT .DLL/.SO at',os.getcwd()
    sys.path.append(os.getcwd())

from PyHyperNEAT import *  
