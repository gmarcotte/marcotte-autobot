#ifndef HCUBE_STL_H_INCLUDED
#define HCUBE_STL_H_INCLUDED

#include <vector>
#include <string>
#include <set>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <climits>
#include <sstream>
#include <list>
#include <map>
#include <stack>
#include <queue>
#include <iomanip>

using namespace std;

#endif // HCUBE_STL_H_INCLUDED
